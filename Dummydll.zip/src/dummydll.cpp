﻿#include "pch.h"
#include "dummydll.h"

float DummyAdd(float a, float b)
{
	return a + b;
}

float DummySubtract(float a, float b)
{
	return a - b;
}
