﻿#include "pch.h"
#include "dummydll.h"

float add(float a, float b)
{
	return a + b;
}

float subtract(float a, float b)
{
	return a - b;
}
